# Contribution 16: Three-hour ordered takedowns are not a universal complaint clock

Working research brief | Exported 5 October 2026

Collection: Five Indian policy and public-service evidence collections. Evidence checked DPDP: 4 October 2026; expansion: 5 October 2026.

Analyst-reviewed extracted English text, not independent legal review or personalized legal advice. Session checks and notes are user annotations, not public editorial approval. No current court-status or exhaustive later-amendment certification is made.

## Timing and scope

Synthetic media: the [amendment](https://www.meity.gov.in/static/uploads/2026/02/f55fe52418b03f58b0669f6a8bc03b6d.pdf) states commencement on 20 February 2026; English citations were [corrected on 26 February](https://www.meity.gov.in/static/uploads/2026/03/20c30107195f68865104dd4e16176f4d.pdf). This is not exhaustive current court-status certification. Some comparisons use prior consolidated law because the final change was absent from the consultation draft.

## Rule 3(1)(d): Three-hour ordered takedowns are not a universal complaint clock

Collection: sgi. Comparison: Prior law to amended law. Type: Timing. Actor/class: Intermediaries and public authorities. Earlier context: Prior Rule 3(1)(d), updated 22 Oct 2025.

Status: Notified amendment; operative-date and court-status limits apply.

### Textual observation

The final shortens the actual-knowledge takedown clock and changes authorisation wording and the police rank threshold. [Prior Rule 3(1)(d), updated 22 Oct 2025](https://www.meity.gov.in/static/uploads/2025/10/708f6a344c74249c2e1bbb6890342f80.pdf) [Final amendment 3(a)(ii); Gazette p. 11](https://www.meity.gov.in/static/uploads/2026/02/f55fe52418b03f58b0669f6a8bc03b6d.pdf)

Earlier excerpt (PRIOR CONSOLIDATED RULE, as extracted):

> remove or disable access to such information within thirty-six hours of the receipt of such actual knowledge

Later excerpt (NOTIFIED AMENDMENT, as printed, as extracted):

> for the words “thirty-six hours”, the words “within three hours” shall be substituted

### Analyst interpretation

The three-hour change belongs to Rule 3(1)(d)'s actual-knowledge pathway. Ordinary user grievances have separate clocks.

### Limits and follow-up

The October draft did not propose this change. Read the underlying court/government actual-knowledge conditions; not every complaint starts this clock.

Reporting question: How are authorised notices authenticated, logged and reviewed before accelerated removal?

## Source provenance

- [Synthetic-media consultation draft](https://www.meity.gov.in/static/uploads/2025/10/9de47fb06522b9e40a61e4731bc7de51.pdf), Draft SGI amendments. Document date: 22 October 2025. Publication metadata: 22 October 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; b54dfd61df6a9c8c8e9f584eb437346a9237e293d342f78af44da79ca2507e36.
- [Notified synthetic-media amendments](https://www.meity.gov.in/static/uploads/2026/02/f55fe52418b03f58b0669f6a8bc03b6d.pdf), G.S.R. 120(E). Document date: 10 February 2026. Publication metadata: 10 February 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; d31804a7666d165f44ed968fd5e4d10a816cc83602af63b1aa56a65b4a686e68.
- [Synthetic-media English-text corrigenda](https://www.meity.gov.in/static/uploads/2026/03/20c30107195f68865104dd4e16176f4d.pdf), G.S.R. 148(E). Document date: 26 February 2026. Publication metadata: 26 February 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; a860908ed1cc7e95db871f483f2bb18de92f87bdf931a94d509537bdd286cb54.
- [Prior consolidated IT Rules](https://www.meity.gov.in/static/uploads/2025/10/708f6a344c74249c2e1bbb6890342f80.pdf), Consolidated IT Rules. Document date: Updated 22 October 2025. Publication metadata: Updated 22 October 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 182a9b90e2a11fb06522e092e1b542a96f8a52f28f648bab7feb10c2eb3f952f.
- [IT Rules incorporating the SGI corrigenda](https://www.meity.gov.in/static/uploads/2026/03/0b576f2071694b52e4cd6bb1b6dfab1e.pdf), Consolidated IT Rules. Document date: 26 February 2026 corrigenda. Publication metadata: 26 February 2026 corrigenda. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; b5198b72c51d9d2ae94d38cd8d6f0214241abcca3473228e1aedb6547e722705.
- [MeitY synthetic-media FAQ](https://www.meity.gov.in/static/uploads/2025/10/065b6deb585441b5ccdf8be42502a49c.pdf), MeitY FAQ. Document date: 10 February 2026. Publication metadata: 10 February 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 9cce731de8e47b91348581f7d9c751f6fb6cc1d64f8d63a4e2c32b61e82e6011.
