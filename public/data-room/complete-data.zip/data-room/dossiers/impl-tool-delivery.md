# Record dossier: Technical tools

Working research brief | Exported 5 October 2026

Collection: Five Indian policy and public-service evidence collections. Evidence checked DPDP: 4 October 2026; expansion: 5 October 2026.

Analyst-reviewed extracted English text, not independent legal review or personalized legal advice. Session checks and notes are user annotations, not public editorial approval. No current court-status or exhaustive later-amendment certification is made.

## Timing and scope

Implementation evidence: constitution, recruitment, selections, commitments and operational outcomes are different milestones. Status describes the reviewed records, not an audit or proof of absence. Sources were checked on 5 October 2026; no agency confirmation was requested.

## Technical tools: Named selections identify owners, not proven detection performance

Collection: impl. Comparison: Recommendation to implementation evidence. Type: Evidence checkpoint. Actor/class: IndiaAI, MeitY and oversight bodies. Earlier context: Part 2.6; printed p. 36.

Status: Programme activity reported.

### Textual observation

The second EOI names five selected projects: three detection projects, an agriculture bias project and Anvil. [Part 2.6; printed p. 36](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf) [Second EOI selection table](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2175698)

Earlier excerpt (POLICY RECOMMENDATION, as extracted):

> Promote the adoption of AI safety tools in areas such bias mitigation, fairness testing, and explainability, through platforms, APIs and open access tools.

Later excerpt (REVIEWED IMPLEMENTATION RECORD, as printed, as extracted):

> List of Projects selected under Second EOI in Safe & Trusted AI pillar of IndiaAI Mission Theme Project Title Selected Applicant Deepfake Detection Tool Saakshya: Multi-Agent, RAG-Enhanced Framework for Deepfake Detection and Governance IIT Jodhpur (CI) & IIT Madras AI Vishleshak: Improving Audio-Visual Deepfake Detection and Handwritten Signature Forgery Detection with Adversarial Robustness, Explainability & Domain Generalization IIT Mandi & Directorate of Forensic Services, Himachal Pradesh Real-Time Voice Deepfake Detection System IIT Kharagpur Bias Mitigation Evaluating Gender Bias in Agriculture LLMs- Creating Digital Public Goods (DPG) for Benchmarking and Fair Data Work Digital Futures Lab & Karya Penetration Testing & Evaluation Anvil: Penetration Testing & Evaluation Tool for LLM and Generative AI Globals ITES Pvt Ltd & IIIT Dharwad

### Analyst interpretation

The table gives journalists identifiable project owners and themes. It does not establish accuracy, robustness, licensing, release status or operational deployment.

### Limits and follow-up

The October 2025 selection predates the November framework; it is relevant programme lineage, not an outcome caused by that framework. The five selections are a subset, not five additional projects beyond the reported thirteen.

Reporting question: Can a reporter reproduce a stated benchmark and inspect false-positive rates before describing a tool as effective?

### Implementation evidence trail

[Second Safe & Trusted AI EOI selections: Second EOI selection table](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2175698)

> List of Projects selected under Second EOI in Safe & Trusted AI pillar of IndiaAI Mission Theme Project Title Selected Applicant Deepfake Detection Tool Saakshya: Multi-Agent, RAG-Enhanced Framework for Deepfake Detection and Governance IIT Jodhpur (CI) & IIT Madras AI Vishleshak: Improving Audio-Visual Deepfake Detection and Handwritten Signature Forgery Detection with Adversarial Robustness, Explainability & Domain Generalization IIT Mandi & Directorate of Forensic Services, Himachal Pradesh Real-Time Voice Deepfake Detection System IIT Kharagpur Bias Mitigation Evaluating Gender Bias in Agriculture LLMs- Creating Digital Public Goods (DPG) for Benchmarking and Fair Data Work Digital Futures Lab & Karya Penetration Testing & Evaluation Anvil: Penetration Testing & Evaluation Tool for LLM and Generative AI Globals ITES Pvt Ltd & IIIT Dharwad

[Safe & Trusted AI parliamentary explanation: 27 July release, named initiatives](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2289946&reg=3&lang=1)

> Key initiatives include: - Saakshya, multi-agent framework developed by IIT Jodhpur & IIT Madras for deep fake detection - AI Vishleshak for improving Audio-Visual forgery detection system - IIT Kharagpur’s project on Real-Time Voice Deepfake Detection System

### Records to request or verify

- Repository or usable release and licence
- Evaluation data, baselines and reproducibility instructions
- Error rates across languages and demographic groups
- Completion, acceptance and deployment records
This is a research checklist, not a filed information request or a determination of the appropriate legal procedure.

## Source provenance

- [India AI Governance Guidelines](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf), IndiaAI framework. Document date: Released 5 November 2025. Publication metadata: Released 5 November 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 628806e4e519e7d832f270bec2d6ab858aaa3252c6d48dcf8941df01fe82acf4.
- [AIGEG constitution memorandum](https://www.meity.gov.in/static/uploads/2026/04/43a4ec455c26b0f061cc7cca98770a45.pdf), AIGEG constitution memorandum. Document date: 13 April 2026. Publication metadata: 13 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; d3a050d627ec3021393b6d2a4ee735ff3206ccafcbd64fe69a9d0a374fad4302.
- [TPEC constitution memorandum](https://d12aarmt01l54a.cloudfront.net/cms/files/constitution-of-tpec/1776447206.pdf), TPEC constitution memorandum. Document date: 13 April 2026. Publication metadata: 13 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 8706c75e434a3dff62e8f4e03ff3444e4d8a7d1ccbfa2f3068c43094707e2513.
- [AIGEG constitution announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2252739&reg=1&lang=1), AIGEG constitution announcement. Document date: 16 April 2026. Publication metadata: 16 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 72d1d7b4e7e932ab5fe41c63a4793ae87e5b1f755d6845da530d0f119da017eb.
- [TPEC constitution announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2253322&reg=1&lang=1), TPEC constitution announcement. Document date: 18 April 2026. Publication metadata: 18 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 13eb1267f72810c12e303353326639b35c2876ea9bc5b8773cdfbec2b3918ef5.
- [IndiaAI Safety Institute partner EOI](https://indiaai.s3.ap-south-1.amazonaws.com/docs/sg-call-for-partnerships-indiaai-safety-institute.pdf), IndiaAI Safety Institute partner EOI. Document date: Published 9 May 2025; deadline 9 June 2025. Publication metadata: Published 9 May 2025; deadline 9 June 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; dc1d68256f8aa317aea70ee70702c63c871bf530f6e4356c07acc2ab031804d0.
- [Safety Institute director recruitment](https://dic.gov.in/jobs/director-indiaai-safety-institute/), Safety Institute director recruitment. Document date: Application deadline 2 June 2026; posting date not certified. Publication metadata: Application deadline 2 June 2026; posting date not certified. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 3ebb8a77360ba717f067ff967eef234f23c3970ff7d91ddf83f0c96c83758274.
- [Safe & Trusted AI parliamentary explanation](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2289946&reg=3&lang=1), Safe & Trusted AI parliamentary explanation. Document date: 27 July 2026. Publication metadata: 27 July 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; f9f82dd190323748b5cddacf8963e5f5cd6680171b80855ff05b8c43d075393d.
- [IndiaAI Mission governance progress explanation](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291062&reg=48&lang=1), IndiaAI Mission governance progress explanation. Document date: 29 July 2026. Publication metadata: 29 July 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 9ee611bf8be80c79cb27f92083f8d3becda9c293c9d53a50f4f699f3befc6de9.
- [Second Safe & Trusted AI EOI selections](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2175698), Second Safe & Trusted AI EOI selections. Document date: 7 October 2025. Publication metadata: 7 October 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 269765d4781774e71e895d703ba6fd75213225c6b4a6c27f61da83613a5de0cf.
- [AI Impact Summit deliverables](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2234343&reg=3&lang=1), AI Impact Summit deliverables. Document date: 2 March 2026. Publication metadata: 2 March 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; a5ef4f9b6d3bba0705146d84c5c1a4338af87100c221afcfef4a9950ffb33281.
- [Deepfake safeguards and grievance explanation](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291671&reg=3&lang=1), Deepfake safeguards and grievance explanation. Document date: 30 July 2026. Publication metadata: 30 July 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; ffafee2530c1b187b615613d0910eddaad17a2f44a57df6c7e398cf028c67a1d.
- [CERT-In cyber incident directions](https://www.cert-in.org.in/PDF/CERT-In_Directions_70B_28.04.2022.pdf), CERT-In cyber incident directions. Document date: 28 April 2022. Publication metadata: 28 April 2022. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 7b5c2b023e5c083b65084ccd84d56fdc37a6bca7f08420e13ca9f61364c6170c.

## All stored record fields

These are the curated record fields, not a complete original instrument or a live-system audit. The quoted text segments are those stored by this collection; open the original for wider context.

```json
{
  "id": "impl-tool-delivery",
  "label": "Technical tools",
  "title": "Named selections identify owners, not proven detection performance",
  "familyId": "impl",
  "comparisonKind": "Recommendation to implementation evidence",
  "legalStatus": "Programme activity reported",
  "evidenceStatus": "Programme activity reported",
  "implementationCheckpoint": true,
  "type": "Evidence checkpoint",
  "actor": "IndiaAI, MeitY and oversight bodies",
  "draftLabel": "Part 2.6; printed p. 36",
  "draftUrl": "https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf",
  "finalUrl": "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2175698",
  "draftLocator": "Part 2.6; printed p. 36",
  "finalLocator": "Second EOI selection table",
  "beforeSourceId": "aig-guidelines",
  "afterSourceId": "impl-projects",
  "beforeLabel": "POLICY RECOMMENDATION",
  "afterLabel": "REVIEWED IMPLEMENTATION RECORD",
  "draftText": "Promote the adoption of AI safety tools in areas such bias mitigation, fairness testing, and explainability, through platforms, APIs and open access tools.",
  "finalText": "List of Projects selected under Second EOI in Safe & Trusted AI pillar of IndiaAI Mission Theme Project Title Selected Applicant Deepfake Detection Tool Saakshya: Multi-Agent, RAG-Enhanced Framework for Deepfake Detection and Governance IIT Jodhpur (CI) & IIT Madras AI Vishleshak: Improving Audio-Visual Deepfake Detection and Handwritten Signature Forgery Detection with Adversarial Robustness, Explainability & Domain Generalization IIT Mandi & Directorate of Forensic Services, Himachal Pradesh Real-Time Voice Deepfake Detection System IIT Kharagpur Bias Mitigation Evaluating Gender Bias in Agriculture LLMs- Creating Digital Public Goods (DPG) for Benchmarking and Fair Data Work Digital Futures Lab & Karya Penetration Testing & Evaluation Anvil: Penetration Testing & Evaluation Tool for LLM and Generative AI Globals ITES Pvt Ltd & IIIT Dharwad",
  "correctedText": "List of Projects selected under Second EOI in Safe & Trusted AI pillar of IndiaAI Mission Theme Project Title Selected Applicant Deepfake Detection Tool Saakshya: Multi-Agent, RAG-Enhanced Framework for Deepfake Detection and Governance IIT Jodhpur (CI) & IIT Madras AI Vishleshak: Improving Audio-Visual Deepfake Detection and Handwritten Signature Forgery Detection with Adversarial Robustness, Explainability & Domain Generalization IIT Mandi & Directorate of Forensic Services, Himachal Pradesh Real-Time Voice Deepfake Detection System IIT Kharagpur Bias Mitigation Evaluating Gender Bias in Agriculture LLMs- Creating Digital Public Goods (DPG) for Benchmarking and Fair Data Work Digital Futures Lab & Karya Penetration Testing & Evaluation Anvil: Penetration Testing & Evaluation Tool for LLM and Generative AI Globals ITES Pvt Ltd & IIIT Dharwad",
  "beforeExcerpt": "Promote the adoption of AI safety tools in areas such bias mitigation, fairness testing, and explainability, through platforms, APIs and open access tools.",
  "afterExcerpt": "List of Projects selected under Second EOI in Safe & Trusted AI pillar of IndiaAI Mission Theme Project Title Selected Applicant Deepfake Detection Tool Saakshya: Multi-Agent, RAG-Enhanced Framework for Deepfake Detection and Governance IIT Jodhpur (CI) & IIT Madras AI Vishleshak: Improving Audio-Visual Deepfake Detection and Handwritten Signature Forgery Detection with Adversarial Robustness, Explainability & Domain Generalization IIT Mandi & Directorate of Forensic Services, Himachal Pradesh Real-Time Voice Deepfake Detection System IIT Kharagpur Bias Mitigation Evaluating Gender Bias in Agriculture LLMs- Creating Digital Public Goods (DPG) for Benchmarking and Fair Data Work Digital Futures Lab & Karya Penetration Testing & Evaluation Anvil: Penetration Testing & Evaluation Tool for LLM and Generative AI Globals ITES Pvt Ltd & IIIT Dharwad",
  "draftPage": 0,
  "finalPage": 0,
  "summary": "The second EOI names five selected projects: three detection projects, an agriculture bias project and Anvil.",
  "interpretation": "The table gives journalists identifiable project owners and themes. It does not establish accuracy, robustness, licensing, release status or operational deployment.",
  "question": "Can a reporter reproduce a stated benchmark and inspect false-positive rates before describing a tool as effective?",
  "caution": "The October 2025 selection predates the November framework; it is relevant programme lineage, not an outcome caused by that framework. The five selections are a subset, not five additional projects beyond the reported thirteen.",
  "evidenceTrail": [
    {
      "sourceId": "impl-projects",
      "url": "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2175698",
      "title": "Second Safe & Trusted AI EOI selections",
      "locator": "Second EOI selection table",
      "quote": "List of Projects selected under Second EOI in Safe & Trusted AI pillar of IndiaAI Mission Theme Project Title Selected Applicant Deepfake Detection Tool Saakshya: Multi-Agent, RAG-Enhanced Framework for Deepfake Detection and Governance IIT Jodhpur (CI) & IIT Madras AI Vishleshak: Improving Audio-Visual Deepfake Detection and Handwritten Signature Forgery Detection with Adversarial Robustness, Explainability & Domain Generalization IIT Mandi & Directorate of Forensic Services, Himachal Pradesh Real-Time Voice Deepfake Detection System IIT Kharagpur Bias Mitigation Evaluating Gender Bias in Agriculture LLMs- Creating Digital Public Goods (DPG) for Benchmarking and Fair Data Work Digital Futures Lab & Karya Penetration Testing & Evaluation Anvil: Penetration Testing & Evaluation Tool for LLM and Generative AI Globals ITES Pvt Ltd & IIIT Dharwad"
    },
    {
      "sourceId": "impl-safety-status",
      "url": "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2289946&reg=3&lang=1",
      "title": "Safe & Trusted AI parliamentary explanation",
      "locator": "27 July release, named initiatives",
      "quote": "Key initiatives include: - Saakshya, multi-agent framework developed by IIT Jodhpur & IIT Madras for deep fake detection - AI Vishleshak for improving Audio-Visual forgery detection system - IIT Kharagpur’s project on Real-Time Voice Deepfake Detection System"
    }
  ],
  "requestChecklist": [
    "Repository or usable release and licence",
    "Evaluation data, baselines and reproducibility instructions",
    "Error rates across languages and demographic groups",
    "Completion, acceptance and deployment records"
  ],
  "relatedId": "aig-techno",
  "evidenceScope": "An implementation checkpoint, not a textual redline or operational audit. Read the whole evidence trail.",
  "reviewStatus": "Analyst-reviewed extracted official records; no agency confirmation requested.",
  "correctionIds": [],
  "contribution": true,
  "featured": false,
  "checked": "5 October 2026"
}
```
