# Record dossier: Grievance redress

Working research brief | Exported 5 October 2026

Collection: Five Indian policy and public-service evidence collections. Evidence checked DPDP: 4 October 2026; expansion: 5 October 2026.

Analyst-reviewed extracted English text, not independent legal review or personalized legal advice. Session checks and notes are user annotations, not public editorial approval. No current court-status or exhaustive later-amendment certification is made.

## Timing and scope

Implementation evidence: constitution, recruitment, selections, commitments and operational outcomes are different milestones. Status describes the reviewed records, not an audit or proof of absence. Sources were checked on 5 October 2026; no agency confirmation was requested.

## Grievance redress: Platform appeals exist; universal AI-harm redress is not established

Collection: impl. Comparison: Recommendation to implementation evidence. Type: Evidence checkpoint. Actor/class: IndiaAI, MeitY and oversight bodies. Earlier context: Part 2.5; printed p. 32.

Status: Limited-scope route documented.

### Textual observation

The July explanation documents intermediary grievance officers and online GAC appeals. [Part 2.5; printed p. 32](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf) [30 July release, Grievance Redressal Mechanism](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291671&reg=3&lang=1)

Earlier excerpt (POLICY RECOMMENDATION, as extracted):

> The Committee recommends that organisations deploying AI systems should establish accessible and effective grievance redressal mechanisms as part of their accountability obligations.

Later excerpt (REVIEWED IMPLEMENTATION RECORD, as printed, as extracted):

> Intermediaries are required to appoint Grievance Officers and resolve complaints within the prescribed timelines. Users can appeal online at https://www.gac.gov.in if their complaints are not addressed by the intermediaries’ Grievance Officers. GACs ensure accountability and transparency of content moderation decisions. The complaints registered with the Police are investigated by the concerned Law Enforcement Agencies (LEAs) under the relevant statutory framework. Since ‘Police’ and ‘Public Order’ are State subjects as per the Seventh Schedule of the Constitution of India, the States/UTs are primarily responsible for the prevention, detection, investigation and prosecution of crimes including cybercrime through their Law Enforcement Agencies (LEAs).

### Analyst interpretation

These are concrete routes for relevant platform-content disputes, not an all-purpose appeal against healthcare, hiring, credit or government AI decisions. A general governance recommendation is not itself a new complaint portal.

### Limits and follow-up

The reviewed records do not establish universal AI-specific redress. Other sectoral, consumer, constitutional or legal remedies may exist; their eligibility and current procedures require separate verification.

Reporting question: For a particular AI decision, which body has jurisdiction, what remedy is available and where is that procedure documented?

### Implementation evidence trail

[Deepfake safeguards and grievance explanation: 30 July release, Grievance Redressal Mechanism](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291671&reg=3&lang=1)

> Intermediaries are required to appoint Grievance Officers and resolve complaints within the prescribed timelines. Users can appeal online at https://www.gac.gov.in if their complaints are not addressed by the intermediaries’ Grievance Officers. GACs ensure accountability and transparency of content moderation decisions. The complaints registered with the Police are investigated by the concerned Law Enforcement Agencies (LEAs) under the relevant statutory framework. Since ‘Police’ and ‘Public Order’ are State subjects as per the Seventh Schedule of the Constitution of India, the States/UTs are primarily responsible for the prevention, detection, investigation and prosecution of crimes including cybercrime through their Law Enforcement Agencies (LEAs).

[India AI Governance Guidelines: Guidelines Part 2.5; printed p. 32](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf)

> The Committee recommends that organisations deploying AI systems should establish accessible and effective grievance redressal mechanisms as part of their accountability obligations. Such mechanisms should be designed to make it easy and reliable for individuals to report harms or concerns, without fear of retaliation or undue burden. Organisations should adopt a proactive approach, ensuring that redressal channels are clearly visible, available in multiple languages and formats, and responsive within reasonable timelines. Feedback received through these channels should be systematically analysed and integrated into product improvements, creating a loop between user experience and risk mitigation. These grievance redressal systems should also be separate from the AI Incidents Database that the Committee has recommended.

### Records to request or verify

- Decision-specific complaint and appeal policy
- Responsible decision-maker and human-review procedure
- Jurisdiction, eligibility and remedies
- Outcome records and accessibility of the route
This is a research checklist, not a filed information request or a determination of the appropriate legal procedure.

## Source provenance

- [India AI Governance Guidelines](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf), IndiaAI framework. Document date: Released 5 November 2025. Publication metadata: Released 5 November 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 628806e4e519e7d832f270bec2d6ab858aaa3252c6d48dcf8941df01fe82acf4.
- [AIGEG constitution memorandum](https://www.meity.gov.in/static/uploads/2026/04/43a4ec455c26b0f061cc7cca98770a45.pdf), AIGEG constitution memorandum. Document date: 13 April 2026. Publication metadata: 13 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; d3a050d627ec3021393b6d2a4ee735ff3206ccafcbd64fe69a9d0a374fad4302.
- [TPEC constitution memorandum](https://d12aarmt01l54a.cloudfront.net/cms/files/constitution-of-tpec/1776447206.pdf), TPEC constitution memorandum. Document date: 13 April 2026. Publication metadata: 13 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 8706c75e434a3dff62e8f4e03ff3444e4d8a7d1ccbfa2f3068c43094707e2513.
- [AIGEG constitution announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2252739&reg=1&lang=1), AIGEG constitution announcement. Document date: 16 April 2026. Publication metadata: 16 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 72d1d7b4e7e932ab5fe41c63a4793ae87e5b1f755d6845da530d0f119da017eb.
- [TPEC constitution announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2253322&reg=1&lang=1), TPEC constitution announcement. Document date: 18 April 2026. Publication metadata: 18 April 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 13eb1267f72810c12e303353326639b35c2876ea9bc5b8773cdfbec2b3918ef5.
- [IndiaAI Safety Institute partner EOI](https://indiaai.s3.ap-south-1.amazonaws.com/docs/sg-call-for-partnerships-indiaai-safety-institute.pdf), IndiaAI Safety Institute partner EOI. Document date: Published 9 May 2025; deadline 9 June 2025. Publication metadata: Published 9 May 2025; deadline 9 June 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; dc1d68256f8aa317aea70ee70702c63c871bf530f6e4356c07acc2ab031804d0.
- [Safety Institute director recruitment](https://dic.gov.in/jobs/director-indiaai-safety-institute/), Safety Institute director recruitment. Document date: Application deadline 2 June 2026; posting date not certified. Publication metadata: Application deadline 2 June 2026; posting date not certified. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 3ebb8a77360ba717f067ff967eef234f23c3970ff7d91ddf83f0c96c83758274.
- [Safe & Trusted AI parliamentary explanation](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2289946&reg=3&lang=1), Safe & Trusted AI parliamentary explanation. Document date: 27 July 2026. Publication metadata: 27 July 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; f9f82dd190323748b5cddacf8963e5f5cd6680171b80855ff05b8c43d075393d.
- [IndiaAI Mission governance progress explanation](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291062&reg=48&lang=1), IndiaAI Mission governance progress explanation. Document date: 29 July 2026. Publication metadata: 29 July 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 9ee611bf8be80c79cb27f92083f8d3becda9c293c9d53a50f4f699f3befc6de9.
- [Second Safe & Trusted AI EOI selections](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2175698), Second Safe & Trusted AI EOI selections. Document date: 7 October 2025. Publication metadata: 7 October 2025. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 269765d4781774e71e895d703ba6fd75213225c6b4a6c27f61da83613a5de0cf.
- [AI Impact Summit deliverables](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2234343&reg=3&lang=1), AI Impact Summit deliverables. Document date: 2 March 2026. Publication metadata: 2 March 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; a5ef4f9b6d3bba0705146d84c5c1a4338af87100c221afcfef4a9950ffb33281.
- [Deepfake safeguards and grievance explanation](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291671&reg=3&lang=1), Deepfake safeguards and grievance explanation. Document date: 30 July 2026. Publication metadata: 30 July 2026. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; ffafee2530c1b187b615613d0910eddaad17a2f44a57df6c7e398cf028c67a1d.
- [CERT-In cyber incident directions](https://www.cert-in.org.in/PDF/CERT-In_Directions_70B_28.04.2022.pdf), CERT-In cyber incident directions. Document date: 28 April 2022. Publication metadata: 28 April 2022. Snapshot integrity: SHA-256 of extracted UTF-8 text, not original PDF bytes; 7b5c2b023e5c083b65084ccd84d56fdc37a6bca7f08420e13ca9f61364c6170c.

## All stored record fields

These are the curated record fields, not a complete original instrument or a live-system audit. The quoted text segments are those stored by this collection; open the original for wider context.

```json
{
  "id": "impl-redress",
  "label": "Grievance redress",
  "title": "Platform appeals exist; universal AI-harm redress is not established",
  "familyId": "impl",
  "comparisonKind": "Recommendation to implementation evidence",
  "legalStatus": "Limited-scope route documented",
  "evidenceStatus": "Limited-scope route documented",
  "implementationCheckpoint": true,
  "type": "Evidence checkpoint",
  "actor": "IndiaAI, MeitY and oversight bodies",
  "draftLabel": "Part 2.5; printed p. 32",
  "draftUrl": "https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf",
  "finalUrl": "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291671&reg=3&lang=1",
  "draftLocator": "Part 2.5; printed p. 32",
  "finalLocator": "30 July release, Grievance Redressal Mechanism",
  "beforeSourceId": "aig-guidelines",
  "afterSourceId": "impl-redress",
  "beforeLabel": "POLICY RECOMMENDATION",
  "afterLabel": "REVIEWED IMPLEMENTATION RECORD",
  "draftText": "The Committee recommends that organisations deploying AI systems should establish accessible and effective grievance redressal mechanisms as part of their accountability obligations.",
  "finalText": "Intermediaries are required to appoint Grievance Officers and resolve complaints within the prescribed timelines. Users can appeal online at https://www.gac.gov.in if their complaints are not addressed by the intermediaries’ Grievance Officers. GACs ensure accountability and transparency of content moderation decisions. The complaints registered with the Police are investigated by the concerned Law Enforcement Agencies (LEAs) under the relevant statutory framework. Since ‘Police’ and ‘Public Order’ are State subjects as per the Seventh Schedule of the Constitution of India, the States/UTs are primarily responsible for the prevention, detection, investigation and prosecution of crimes including cybercrime through their Law Enforcement Agencies (LEAs).",
  "correctedText": "Intermediaries are required to appoint Grievance Officers and resolve complaints within the prescribed timelines. Users can appeal online at https://www.gac.gov.in if their complaints are not addressed by the intermediaries’ Grievance Officers. GACs ensure accountability and transparency of content moderation decisions. The complaints registered with the Police are investigated by the concerned Law Enforcement Agencies (LEAs) under the relevant statutory framework. Since ‘Police’ and ‘Public Order’ are State subjects as per the Seventh Schedule of the Constitution of India, the States/UTs are primarily responsible for the prevention, detection, investigation and prosecution of crimes including cybercrime through their Law Enforcement Agencies (LEAs).",
  "beforeExcerpt": "The Committee recommends that organisations deploying AI systems should establish accessible and effective grievance redressal mechanisms as part of their accountability obligations.",
  "afterExcerpt": "Intermediaries are required to appoint Grievance Officers and resolve complaints within the prescribed timelines. Users can appeal online at https://www.gac.gov.in if their complaints are not addressed by the intermediaries’ Grievance Officers. GACs ensure accountability and transparency of content moderation decisions. The complaints registered with the Police are investigated by the concerned Law Enforcement Agencies (LEAs) under the relevant statutory framework. Since ‘Police’ and ‘Public Order’ are State subjects as per the Seventh Schedule of the Constitution of India, the States/UTs are primarily responsible for the prevention, detection, investigation and prosecution of crimes including cybercrime through their Law Enforcement Agencies (LEAs).",
  "draftPage": 0,
  "finalPage": 0,
  "summary": "The July explanation documents intermediary grievance officers and online GAC appeals.",
  "interpretation": "These are concrete routes for relevant platform-content disputes, not an all-purpose appeal against healthcare, hiring, credit or government AI decisions. A general governance recommendation is not itself a new complaint portal.",
  "question": "For a particular AI decision, which body has jurisdiction, what remedy is available and where is that procedure documented?",
  "caution": "The reviewed records do not establish universal AI-specific redress. Other sectoral, consumer, constitutional or legal remedies may exist; their eligibility and current procedures require separate verification.",
  "evidenceTrail": [
    {
      "sourceId": "impl-redress",
      "url": "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2291671&reg=3&lang=1",
      "title": "Deepfake safeguards and grievance explanation",
      "locator": "30 July release, Grievance Redressal Mechanism",
      "quote": "Intermediaries are required to appoint Grievance Officers and resolve complaints within the prescribed timelines. Users can appeal online at https://www.gac.gov.in if their complaints are not addressed by the intermediaries’ Grievance Officers. GACs ensure accountability and transparency of content moderation decisions. The complaints registered with the Police are investigated by the concerned Law Enforcement Agencies (LEAs) under the relevant statutory framework. Since ‘Police’ and ‘Public Order’ are State subjects as per the Seventh Schedule of the Constitution of India, the States/UTs are primarily responsible for the prevention, detection, investigation and prosecution of crimes including cybercrime through their Law Enforcement Agencies (LEAs)."
    },
    {
      "sourceId": "aig-guidelines",
      "url": "https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/nov/doc2025115685601.pdf",
      "title": "India AI Governance Guidelines",
      "locator": "Guidelines Part 2.5; printed p. 32",
      "quote": "The Committee recommends that organisations deploying AI systems should establish accessible and effective grievance redressal mechanisms as part of their accountability obligations. Such mechanisms should be designed to make it easy and reliable for individuals to report harms or concerns, without fear of retaliation or undue burden. Organisations should adopt a proactive approach, ensuring that redressal channels are clearly visible, available in multiple languages and formats, and responsive within reasonable timelines. Feedback received through these channels should be systematically analysed and integrated into product improvements, creating a loop between user experience and risk mitigation. These grievance redressal systems should also be separate from the AI Incidents Database that the Committee has recommended."
    }
  ],
  "requestChecklist": [
    "Decision-specific complaint and appeal policy",
    "Responsible decision-maker and human-review procedure",
    "Jurisdiction, eligibility and remedies",
    "Outcome records and accessibility of the route"
  ],
  "relatedId": "aig-accountability",
  "evidenceScope": "An implementation checkpoint, not a textual redline or operational audit. Read the whole evidence trail.",
  "reviewStatus": "Analyst-reviewed extracted official records; no agency confirmation requested.",
  "correctionIds": [],
  "contribution": true,
  "featured": false,
  "checked": "5 October 2026"
}
```
