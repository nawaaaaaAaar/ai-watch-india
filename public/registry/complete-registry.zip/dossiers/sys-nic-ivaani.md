# AI Watch: NIC IVAANI computer-vision services

India institution-and-system dataset v1.3.0. Checked 2026-10-05; analyst-coded documentary evidence, not an operational audit. System kind: Government enabling infrastructure. Research cohort: 1.3.0. Selection: Scaling cohort: purposive named family; variants and installations coalesced.

## Owner & purpose

Evidence status: Documented. National Informatics Centre; source-stated institutional responsibility for NIC IVAANI computer-vision services, not certified legal ownership.

> Departments & Organizations with providing various AI services facilitated through Meghraj Cloud of NIC such as : ### Image & Video Analytics Assistance by NIC (IVAANI): It is a bouquet
>
> [NIC AI service portfolios: IVAANI, TAANI and VANI](https://www.nic.gov.in/centre-of-excellence-for-artificial-intelligence/); Reviewed contextual excerpt anchored at: Image & Video Analytics Assistance by NIC.

## Decision role & affected people

Evidence status: Partial. Provide government image/video analytics APIs; verification, image and video components coalesced. Output is not automatically a lawful or correct final decision; adverse-output pathways not tested.

> Departments & Organizations with providing various AI services facilitated through Meghraj Cloud of NIC such as : ### Image & Video Analytics Assistance by NIC (IVAANI): It is a bouquet
>
> [NIC AI service portfolios: IVAANI, TAANI and VANI](https://www.nic.gov.in/centre-of-excellence-for-artificial-intelligence/); Reviewed contextual excerpt anchored at: Image & Video Analytics Assistance by NIC.

## Deployment & date

Evidence status: Partial. Official service portfolio described. Documentary status, not an independent October operational audit.

> Departments & Organizations with providing various AI services facilitated through Meghraj Cloud of NIC such as : ### Image & Video Analytics Assistance by NIC (IVAANI): It is a bouquet
>
> [NIC AI service portfolios: IVAANI, TAANI and VANI](https://www.nic.gov.in/centre-of-excellence-for-artificial-intelligence/); Reviewed contextual excerpt anchored at: Image & Video Analytics Assistance by NIC.

## Procurement & supplier

Evidence status: Not verified. n.a.; executed current award, supplier/processor chain and contractual terms not established in reviewed material.



## Funding & contract

Evidence status: Not verified. n.a.; system-specific allocation, award, expenditure and reconciliation not established; broader programme budgets not assigned.



## Data & integration

Evidence status: Partial. Images, faces and video supplied by relying departments. Complete live flow, production version and training reuse not independently verified.

> Departments & Organizations with providing various AI services facilitated through Meghraj Cloud of NIC such as : ### Image & Video Analytics Assistance by NIC (IVAANI): It is a bouquet
>
> [NIC AI service portfolios: IVAANI, TAANI and VANI](https://www.nic.gov.in/centre-of-excellence-for-artificial-intelligence/); Reviewed contextual excerpt anchored at: Image & Video Analytics Assistance by NIC.

## Evaluation & error rates

Evidence status: Not verified. n.a.; current-version independent evaluation, error/subgroup rates and reproducible protocol not established.



## Human review & overrides

Evidence status: Not verified. n.a.; complete system-specific human review/override procedure and enforcement not established.



## Privacy & retention

Evidence status: Not verified. n.a.; complete system-specific retention/access/training policies and enforcement not established.



## Complaints & appeal

Evidence status: Not verified. n.a.; system-specific adverse-output appeal and remedy outcomes not established.



## Public outputs & access

Evidence status: Documented. Original URLs and selected excerpts supplied; no citizen records or full original document binaries mirrored.

> Departments & Organizations with providing various AI services facilitated through Meghraj Cloud of NIC such as : ### Image & Video Analytics Assistance by NIC (IVAANI): It is a bouquet
>
> [NIC AI service portfolios: IVAANI, TAANI and VANI](https://www.nic.gov.in/centre-of-excellence-for-artificial-intelligence/); Reviewed contextual excerpt anchored at: Image & Video Analytics Assistance by NIC.

## Current-status limits

Evidence status: Partial. Source attribution is not independent validation, full rollout, lawful processing, safety or causal effectiveness. Unknowns mean unestablished within this corpus, not absent.

> Departments & Organizations with providing various AI services facilitated through Meghraj Cloud of NIC such as : ### Image & Video Analytics Assistance by NIC (IVAANI): It is a bouquet
>
> [NIC AI service portfolios: IVAANI, TAANI and VANI](https://www.nic.gov.in/centre-of-excellence-for-artificial-intelligence/); Reviewed contextual excerpt anchored at: Image & Video Analytics Assistance by NIC.

## Deployments

- **event date**: Unknown / not assigned
- **date precision**: Source report / policy date, not actual go-live; undated where date unestablished
- **stage**: Official service portfolio described
- **place**: India
- **description**: Official service portfolio described. Documentary status, not an independent October operational audit.

> Departments & Organizations with providing various AI services facilitated through Meghraj Cloud of NIC such as : ### Image & Video Analytics Assistance by NIC (IVAANI): It is a bouquet
>
> [NIC AI service portfolios: IVAANI, TAANI and VANI](https://www.nic.gov.in/centre-of-excellence-for-artificial-intelligence/); Reviewed contextual excerpt anchored at: Image & Video Analytics Assistance by NIC.

